package com.example.currency;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class USDActivity extends AppCompatActivity implements View.OnClickListener {

    final String CURRENCY_NAME = "Currency name";
    final String CURRENCY_VALUE = "Currency value";
    final String IMAGE_ID = "Image id";

    String[] from = {CURRENCY_NAME,CURRENCY_VALUE,IMAGE_ID};
    int[] to = {R.id.tvName,R.id.tvValue,R.id.imageView};



    int[] images = {
            R.drawable.argentina,
            R.drawable.australia,
            R.drawable.bahrain,
            R.drawable.botswana,
            R.drawable.brazil,
            R.drawable.brunei,
            R.drawable.bulgaria,
            R.drawable.canada,
            R.drawable.chile,
            R.drawable.china,
            R.drawable.colombia,
            R.drawable.croatia,
            R.drawable.czech_republic,
            R.drawable.denmark,
            R.drawable.european_union,
            R.drawable.hong_kong,
            R.drawable.hungary,
            R.drawable.iceland,
            R.drawable.india,
            R.drawable.indonesia,
            R.drawable.iran,
            R.drawable.israel,
            R.drawable.japan,
            R.drawable.kazakhstan,
            R.drawable.south_korea,
            R.drawable.kuwait,
            R.drawable.libya,
            R.drawable.malaysia,
            R.drawable.mauritania,
            R.drawable.mexico,
            R.drawable.nepal,
            R.drawable.new_zealand,
            R.drawable.norway,
            R.drawable.oman,
            R.drawable.pakistan,
            R.drawable.philippines,
            R.drawable.poland,
            R.drawable.qatar,
            R.drawable.romania,
            R.drawable.russia,
            R.drawable.saudi_arabia,
            R.drawable.singapore,
            R.drawable.south_africa,
            R.drawable.sri_lanka,
            R.drawable.sweden,
            R.drawable.switzerland,
            R.drawable.taiwan,
            R.drawable.thailand,
            R.drawable.trinidad_and_tobago,
            R.drawable.turkey,
            R.drawable.united_arab_emirates,
            R.drawable.united_kingdom,
    };


    Document doc;

    Thread myThread;
    Runnable runnable;
    LinearLayout linearLayout;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usd);
        getSupportActionBar().hide();

        linearLayout = findViewById(R.id.main_layout2);









        getCurrenciesValue();

        linearLayout.setOnClickListener(this);



    }

    private void getCurrenciesValue(){

        runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    doc = Jsoup.connect("https://www.x-rates.com/table/?from=USD&amount=1").get();
                    Element table = doc.getElementsByTag("tbody").get(1);





                    ArrayList<Map<String, Object>> data = new ArrayList<Map<String, Object>>();

                    Map<String, Object> map;

                    DecimalFormat decimalFormat = new DecimalFormat("#.#####");

                    for (int i = 0; i<table.childrenSize()-1;i++) {
                        map = new HashMap<String, Object>();
                        map.put(CURRENCY_NAME, table.child(i).child(0).text());
                        double exchange_rate = Double.parseDouble(table.child(i).child(2).text());
                        String exchange_rate_string = decimalFormat.format(exchange_rate);
                        map.put(CURRENCY_VALUE, exchange_rate_string);
                        map.put(IMAGE_ID,images[i]);
                        data.add(map);

                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            SimpleAdapter simpleAdapter = new SimpleAdapter(USDActivity.this, data, R.layout.item, from, to);

                            ListView listView = findViewById(R.id.ListView);

                            listView.setAdapter(simpleAdapter);
                        }
                    });


                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        };
        myThread = new Thread(runnable);
        myThread.start();



    }


    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, EURActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.diagonaltranslate,R.anim.alpha);
        finish();
    }
}