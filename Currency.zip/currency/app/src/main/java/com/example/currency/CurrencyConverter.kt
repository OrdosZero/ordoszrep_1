package com.example.currency

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.constraintlayout.widget.ConstraintLayout
import org.jsoup.nodes.Document
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.select.Elements
import java.text.DecimalFormat
import kotlin.concurrent.thread

class CurrencyConverter : AppCompatActivity() {


    var baseCurrency = "USD"
    var convertedCurrency = "RUB"






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_currency_converter)
        getSupportActionBar()?.hide()
        var spinner = findViewById<Spinner>(R.id.spinner1)
        var spinner2 = findViewById<Spinner>(R.id.spinner2)
        spinnerSetup()

        val editText = findViewById<EditText>(R.id.edText)

        val button = findViewById<Button>(R.id.button)

        val clickLayout  = findViewById<ConstraintLayout>(R.id.clickLayout)



        clickLayout.setOnClickListener{
            var intent = Intent(this, RUBActivity::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.diagonaltranslate,R.anim.alpha)

        }


        button.setOnClickListener{
            if ((spinner.selectedItem != spinner2.selectedItem) && (!editText.text.toString().equals("")) ){
                getCurrencyValue()}
        }


    }


    private fun spinnerSetup(){
        val spinner: Spinner = findViewById(R.id.spinner1)
        val spinner2:Spinner = findViewById(R.id.spinner2)

        ArrayAdapter.createFromResource(
                this,
                R.array.currencies,
                android.R.layout.simple_spinner_item).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_item)
            spinner.adapter = adapter
            spinner2.adapter =adapter
                }

        spinner.onItemSelectedListener = (object: AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                baseCurrency = parent?.getItemAtPosition(position).toString()
            }
        })
        spinner2.onItemSelectedListener = (object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                convertedCurrency = parent?.getItemAtPosition(position).toString()


            }
        })
    }
    fun getCurrencyValue() {
        thread {
            val document: Document = Jsoup.connect("https://www.google.com/search?q=$baseCurrency+to+$convertedCurrency").get()
            val elements: Elements = document.getElementsByClass("DFlfde SwHCTb")
            val element: Element = elements.first()
            Log.d("TAG", element.text())
            val new_element = element.text().replace(',','.')
            val value: Double = new_element.toDouble()
            runOnUiThread(Runnable {
                val spinner: Spinner = findViewById(R.id.spinner1)
                val spinner2:Spinner = findViewById(R.id.spinner2)
                val editText = findViewById<EditText>(R.id.edText)
                val value_new: Double = (editText.text.toString().toDouble() * value)
                val formatting = DecimalFormat("#.#####")
                val value_new2 = formatting.format(value_new)
                val tv1 = findViewById<TextView>(R.id.tv1)
                val tv2 = findViewById<TextView>(R.id.tv2)
                val tv3 = findViewById<TextView>(R.id.tv3)
                tv1.text = editText.text.toString()+ " " + spinner.selectedItem
                tv2.text = "="
                tv3.text = value_new2.toString() + " " + spinner2.selectedItem
            })

        }

        }

    }










